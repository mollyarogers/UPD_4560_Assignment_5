﻿# -*- coding: utf-8 -*-
# park_provisions_MR.py
# Molly Rogers, rogersm@iastate.edu
# November 25th, 2026
# Original script by Brian Gelder
# Version: Python 3.13.13 (ArcGIS Pro)
# This program analyzes census blocks to determine
# access to parks and public lands within a selected Iowa city. 
# The program uses statewide OpenStreetMap data to identify
# parks and allows the user to select different cities.

# import modules
import os
import sys
import time
import traceback
from os.path import join as opj

try:
    start = time.perf_counter()
    import arcpy
    # set up inputs -
    # all city boundaries for Iowa


    # set up inputs -
    # all city boundaries for Iowa
    city_boundaries = arcpy.GetParameterAsText(0)
    # US census blocks for Iowa from 2010
    state_census = arcpy.GetParameterAsText(1)
    # Statewide OpenStreetMap points of interest
    state_pois = arcpy.GetParameterAsText(2)
    # open space #1, state and county lands
    public_lands = arcpy.GetParameterAsText(3)

    # set up output feature class variable
    output_fc = arcpy.GetParameterAsText(4)

    # distance to buffer features as float
    buff_dist = arcpy.GetParameterAsText(5) #Meters
    buff_value = buff_dist.split()[0]
    # city to process as string
    cityName = arcpy.GetParameterAsText(6)



    # set up environments
    arcpy.env.scratchWorkspace = 'in_memory'#'memory'#
    arcpy.env.workspace = 'in_memory'#outputGDB
    arcpy.AddMessage('scratch is ' + str(arcpy.env.scratchWorkspace))
    arcpy.env.overwriteOutput = True

    # start processing
    #'Selecting city'
    arcpy.AddMessage('Selecting city')
    cityBoundary = arcpy.Select_analysis(city_boundaries, where_clause = 'NAME10 = \'' + cityName + '\'')

    #'Buffering city to accomodate open space at city limits'
    arcpy.AddMessage('Buffering city')
    cityBoundaryBuffer = arcpy.Buffer_analysis(cityBoundary, buffer_distance_or_field = buff_dist)

    #'Clipping census blocks to city limits'
    arcpy.AddMessage('Clipping census blocks')
    cityCensusBlocks = arcpy.Clip_analysis(state_census, cityBoundary)

    #'Clipping public lands to those near city'
    arcpy.AddMessage('Clipping public lands')
    cityPublicLands = arcpy.Clip_analysis(public_lands, cityBoundaryBuffer)

    # Select only parks from the statewide OSM dataset
    arcpy.AddMessage('Selecting parks from statewide OSM data')
    stateParks = arcpy.Select_analysis(state_pois, where_clause="fclass = 'park'")
    
    # Clip parks to the buffered city boundary
    arcpy.AddMessage('Clipping parks')
    cityParks = arcpy.Clip_analysis(stateParks, cityBoundaryBuffer)

    # Merge clipped parks and public lands
    arcpy.AddMessage('Merging parks and public lands data')
    openMerge = arcpy.Merge_management([cityParks, cityPublicLands])
    
    #'Buffer open space and dissolve overlapping buffers'
    # to prevent double_counting accessible census block area 
    arcpy.AddMessage('Buffering open space')
    cityPublicBuffer = arcpy.Buffer_analysis(openMerge, buffer_distance_or_field = buff_dist, dissolve_option = "ALL")

    # Intersect buffered open space with census bloc features
    cityIntersectBuffer = arcpy.Intersect_analysis([cityCensusBlocks, cityPublicBuffer])

    # Create fields to store analysis information
    # Block Access will store the total area w/i walking distance of open space
    addAccess = arcpy.AddField_management(cityCensusBlocks, 'BLK_ACCESS', 'DOUBLE', 10, 3)
    # Access_Fraction will store a normalized ranking of the total area w/i walking distance/total census block area
    # Calculate to see how much of a census block is within the walkable buffer of open space
    addFrac = arcpy.AddField_management(cityCensusBlocks, 'ACC_FRAC', 'DOUBLE', 10, 3)

    arcpy.AddMessage('Census blocks: ' + str([fld.name for fld in arcpy.ListFields(cityCensusBlocks)]))
    #'Processing data by Census Blocks...'
    arcpy.AddMessage('Starting calculations')
    
    row_count = int(arcpy.GetCount_management(cityCensusBlocks).getOutput(0))
    i = 0
    arcpy.SetProgressor('step', 'Processing Census Blocks...', 0, row_count, 1)
    
    with arcpy.da.UpdateCursor(cityCensusBlocks, ['GEOID10', addAccess.getInput(1), addFrac.getInput(1), 'SHAPE@']) as ucur:
        for urow in ucur:
            arcpy.SetProgressorLabel('Processing Census Block #' + str(i))
            arcpy.SetProgressorPosition()

            cumArea = 0.0
            #A census block may be in multiple features, so cumulate by census identifier, GEOID10
            with arcpy.da.SearchCursor(cityIntersectBuffer, 'SHAPE@AREA', '"GEOID10" = \'' + urow[0] + '\'') as scur:
                for srow in scur:
                    cumArea += srow[0]
            #Update with total area of census block in walkable buffer
            urow[1] = cumArea
            #Normalize above by dividing by total area of census block
            # area coming from geometry (SHAPE@) object
            block_area = urow[3].area
            urow[2] = cumArea/block_area#urow[3]
            #Commit new values to 
            ucur.updateRow(urow)

            # advance progressor counter
            i += 1

    # reset progressor
    arcpy.ResetProgressor()
    arcpy.AddMessage('Calculating distance from blocks to open space')
    gnt = arcpy.GenerateNearTable_analysis(cityCensusBlocks, openMerge, closest = 'ALL', search_radius = buff_dist)

    addInv = arcpy.AddField_management(gnt, 'INV_DIST', 'DOUBLE')
    arcpy.CalculateField_management(gnt, addInv.getInput(1), str(buff_value)+ ' - !NEAR_DIST!', 'PYTHON_9.3')

    arcpy.AddMessage('Running statistics on second method')
    stats = arcpy.Statistics_analysis(gnt, statistics_fields = [[addInv.getInput(1), 'SUM']], case_field = 'IN_FID')#descGnt.OIDFieldName)

    descCensus = arcpy.Describe(cityCensusBlocks)
    sumField = stats.getInput(1).split()[1] + '_' + addInv.getInput(1)
    arcpy.JoinField_management(cityCensusBlocks, descCensus.OIDFieldName, stats, 'IN_FID', [sumField])

    arcpy.AddMessage('Copying results')
    ## copy the final output to the GDB
    arcpy.CopyFeatures_management(cityCensusBlocks, output_fc)

except:
    # Get the traceback object
    tb = sys.exc_info()[2]
    tbinfo = traceback.format_tb(tb)[0]

    # Concatenate information together concerning the error into a message string
    pymsg = "PYTHON ERRORS:\nTraceback info:\n" + tbinfo + "\nError Info:\n" + str(sys.exc_info()[1])
    arcpy.AddMessage(pymsg + "\n")

    if arcpy.GetMessages(2) not in pymsg:
        msgs = "ArcPy ERRORS:\n" + arcpy.GetMessages(2) + "\n"
        arcpy.AddError(msgs)
        arcpy.AddMessage(msgs)

finally:
    end = time.perf_counter()
    arcpy.AddMessage(f'Execution took: {end-start} seconds')
